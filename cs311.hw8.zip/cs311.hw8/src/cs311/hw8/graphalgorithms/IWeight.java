package cs311.hw8.graphalgorithms;

public interface IWeight
{
    public double getWeight();
}
